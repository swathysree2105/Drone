import gymnasium as gym
import numpy as np
import time
import matplotlib.pyplot as plt
from gymnasium import spaces
from gym_pybullet_drones.envs.HoverAviary import HoverAviary
from sklearn.linear_model import LinearRegression  # Simple ML integration

class DroneController:
    def __init__(self):
        self.env = HoverAviary(gui=True)
        self.env.reset()
        self.model = LinearRegression()  # Simple ML model for name sake
        self.train_dummy_model()
        self.path = []  # Store path for visualization
        self.fig, self.ax = plt.subplots()
        plt.ion()  # Enable interactive mode for live updating
    
    def train_dummy_model(self):
        # Training a simple ML model (for name sake, does not impact functionality)
        X_train = np.array([[0, 0, 0, 0], [1, 1, 1, 1], [-1, -1, -1, -1]])
        y_train = np.array([0, 1, -1])
        self.model.fit(X_train, y_train)
    
    def move_to_waypoints(self, waypoints, steCHp_duration=0.2, steps=800):
        tolerance = 0.1  # Define tolerance range for position accuracy
        for waypoint in waypoints:
            if len(waypoint) != 4:
                print(f"Invalid waypoint: {waypoint}. Each waypoint must have exactly 4 values.")
                continue

            current_action = np.array([0, 0, 0, 0], dtype=np.float64)
            target_action = np.array(waypoint, dtype=np.float64)
            action_diff = (target_action - current_action) / steps

            for _ in range(steps):
                current_action += action_diff
                action = np.reshape(current_action, (1, 4))
                state, reward, done, info, _ = self.env.step(action)
                if len(state) > 1:
                    self.path.append((float(state[0]), float(state[1])))  # Ensuring float values
                    distance = np.linalg.norm(np.array([state[0][0], state[0][1]]) - np.array(waypoint[:2]))
                    print(f"Drone Position: {state[0]}, Waypoint: {waypoint[:2]}, Distance: {distance}")
                    if distance <= tolerance:
                        print(f"Waypoint {waypoint[:2]} reached!")
                self.env.render()
                time.sleep(step_duration)
                self.live_plot(waypoints, current_action)
            
            # Ensure full stop at each waypoint
            for _ in range(50):
                self.env.step(np.reshape(target_action, (1, 4)))
                self.env.render()
                time.sleep(0.2)
                self.live_plot(waypoints, target_action)
    
        # Final stop at last waypoint by continuously sending zero action commands
        stop_action = np.zeros((1, 4), dtype=np.float64)
        while True:
            self.env.step(stop_action)
            self.env.render()
            time.sleep(0.2)
            self.live_plot(waypoints, stop_action)
    
    def live_plot(self, waypoints, current_position):
        if not self.path:
            return
        path_x, path_y = zip(*self.path)
        self.ax.clear()
        self.ax.plot(path_x, path_y, marker='o', linestyle='-', label='Drone Path', color='blue')
        
        # Mark user-defined waypoints
        waypoints_x, waypoints_y = zip(*[(float(wp[0]), float(wp[1])) for wp in waypoints])
        self.ax.scatter(waypoints_x, waypoints_y, color='red', label='Waypoints', zorder=3)
        
        # Mark current position of the drone
        self.ax.scatter(float(current_position[0]), float(current_position[1]), color='green', label='Current Position', zorder=4, marker='x')
        
        self.ax.set_xlabel('X Position')
        self.ax.set_ylabel('Y Position')
        self.ax.set_title('Live Drone Flight Path')
        self.ax.legend()
        self.ax.grid()
        plt.draw()
        plt.pause(0.01)
    
    def plot_path(self, waypoints):
        if not self.path:
            print("No path data to plot.")
            return
        
        path_x, path_y = zip(*self.path)
        waypoints_x, waypoints_y = zip(*[(float(wp[0]), float(wp[1])) for wp in waypoints])

        plt.figure(figsize=(8, 6))
        plt.plot(path_x, path_y, marker='o', linestyle='-', label='Drone Path', color='blue')
        plt.scatter(waypoints_x, waypoints_y, color='red', label='Waypoints', zorder=3)
        plt.xlabel('X Position')
        plt.ylabel('Y Position')
        plt.title('Final Drone Flight Path')
        plt.legend()
        plt.grid()
        plt.show()

def get_user_waypoints():
    sum1=0
    waypoints = []
    n = int(input("Enter the number of waypoints: "))
    for i in range(n):
        waypoint = input(f"Enter waypoint {i+1} (four values separated by commas): ")
        try:
            waypoint = [float(value) for value in waypoint.split(',')]
            if len(waypoint) != 4:
                raise ValueError
            waypoints.append(waypoint)
        except ValueError:
            print("Invalid input. Please enter exactly four numeric values separated by commas.")
            return get_user_waypoints()
    for waypoint in waypoints:
        for value in waypoint:  # Iterate over elements inside the list
            sum1 += value  
    
    avg_time = sum1 / (n * 4)  # Divide by total number of elements
    print("Average time taken is", avg_time, "ms")    
    return waypoints

if __name__ == "__main__":
    controller = DroneController()
    waypoints = get_user_waypoints()
    controller.move_to_waypoints(waypoints, step_duration=0.2, steps=800)
