import time
from environment import DroneNavigationAviary
from gym_pybullet_drones.utils.enums import DroneModel
import pybullet as p

def main():
    env = DroneNavigationAviary(
        drone_model=DroneModel.CF2X,
        num_drones=1,
        gui=True
    )

    env.reset()
    

    p.resetDebugVisualizerCamera(
        cameraDistance=6,
        cameraYaw=45,
        cameraPitch=-30,
        cameraTargetPosition=[0, 0, 0]
    )
    
    print("Environment Visualization Started")
    print("Press Ctrl+C to exit")
    
    try:
        while True:
            time.sleep(0.1)  
            
    except KeyboardInterrupt:
        print("\nVisualization ended by user")
    
    env.close()

if __name__ == "__main__":
    main()