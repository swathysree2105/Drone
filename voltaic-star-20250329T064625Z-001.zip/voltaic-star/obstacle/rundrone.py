import gym
import numpy as np
import time
from gym_pybullet_drones.utils.enums import ActionType
from environment import DroneNavigationAviary

# Initialize the environment with 1 drone
env = DroneNavigationAviary(gui=True, num_drones=1)
obs = env.reset()

# Semi-circle movement parameters
radius = 5.0  # Radius of the semi-circle
angular_speed = 0.05  # How fast the drone moves along the curve
theta = 0  # Start angle
max_theta = np.pi  

# Vertical movement parameters
target_altitude = 2.0  # Initial target altitude
altitude_correction = 0.1  # Increase the altitude correction factor

# Upward movement parameters
upward_speed = 0.1  # Speed of upward movement

done = False
in_upward_phase = False

while not done:
    current_altitude = obs[2]  # Extract current altitude from observation

    if not in_upward_phase:
        # Compute next position in semi-circle
        x_position = radius * np.cos(theta)
        y_position = radius * np.sin(theta)

        # Increase the angle to move along the arc
        theta += angular_speed
        if theta >= max_theta:
            in_upward_phase = True  # Switch to upward movement
            target_altitude = current_altitude  # Set the current altitude as the new target
    else:
        # Maintain position in x and y axes, focus on increasing altitude
        x_position = 0.0
        y_position = 0.0

        # Increase the target altitude
        target_altitude += upward_speed

    # Proportional altitude correction
    altitude_error = target_altitude - current_altitude
    altitude_action = altitude_error * altitude_correction  # More aggressive altitude control

    # Define the action: [thrust, roll, pitch, yaw]
    action = np.array([
        0.5 + altitude_action,  # Adjust thrust for altitude stability
        x_position * 0.1,  # Move based on x-coordinates
        y_position * 0.1,  # Move based on y-coordinates
        0.0   # No yaw rotation
    ])

    # Ensure action values stay within [0, 1]
    action = np.clip(action, 0, 1)

    # Step simulation
    obs, reward, terminated, truncated, info = env.step(action)

    # Check if the environment is done
    done = done or terminated or truncated

    # Render the environment
    env.render()

    # Slow down the simulation for better visualization
    time.sleep(0.1)

# Keep the window open for 10 seconds
time.sleep(10)
env.close()
