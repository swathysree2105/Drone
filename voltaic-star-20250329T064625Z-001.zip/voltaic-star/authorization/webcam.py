import cv2

# ✅ Initialize OpenCV QR code detector
qr_decoder = cv2.QRCodeDetector()

# ✅ Define authorized QR code details
authorized_details = "Name:John Order-ID:61537 Address:12/3 ABC street,Chennai"


# ✅ Open the webcam (0 for default webcam)
cap = cv2.VideoCapture(0)

if not cap.isOpened():
    print("Error: Could not open webcam.")
    exit()

print("📡 Scanning for QR code... Press 'q' to quit.")

while True:
    # ✅ Capture frame from webcam
    ret, frame = cap.read()
    
    if not ret:
        print("Error: Could not read frame.")
        break

    # ✅ Detect and decode the QR code
    qr_data, bbox, _ = qr_decoder.detectAndDecode(frame)

    if qr_data:
        print(f"✅ QR Code Detected: {qr_data}")

        # ✅ Check authorization
        if qr_data.strip() == authorized_details:
            print("🚚 DELIVERED")
        else:
            print("⛔ UNAUTHORISED")

        # ✅ Ensure bbox is not None before drawing
        if bbox is not None and len(bbox) > 0:
            bbox = bbox.astype(int)  # Convert to integers
            for i in range(len(bbox[0])):  # Loop through bbox points
                cv2.line(frame, tuple(bbox[0][i]), tuple(bbox[0][(i+1) % len(bbox[0])]), (0, 255, 0), 3)

    # ✅ Show the webcam feed
    cv2.imshow("QR Code Scanner", frame)

    # ✅ Press 'q' to exit the loop
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# ✅ Release the webcam and close windows
cap.release()
cv2.destroyAllWindows()
